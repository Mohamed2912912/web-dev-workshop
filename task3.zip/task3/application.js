
$(".title").mouseenter( function(){
    $(this).animate({ margin: -8, width: "+=5", height: "+=5" });
});
$(".title").mouseleave( function(){
    $(this).animate({ margin: 0, width: "-=5", height: "-=5" });
});




$("#download").click( function(){
    
    $("#dload").show();
});


$("#more_info").click( function(){
    
    $("#go_to_about").show();
});


$("#sign-btn").click( function(){
    
    $("#boxx").show();
});